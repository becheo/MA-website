"Helper functions for voltage curve creation"

import numpy as np
import matplotlib.pyplot as plt
import pandas


samplerate_write = 250


def create_array():
    """Create numpy array"""
    return np.array([0], dtype=np.float64)


def voltage_hold(array, duration):
    '''Create voltage holding curve'''
    holdvalue = array[-1]
    value = np.array([np.repeat([holdvalue], (duration*samplerate_write))],
                     dtype=np.float64)  # 20 Sekunden bei 500 Hz
    array = np.append(array, value)
    return array


def voltage_alter(array, duration, endvalue):
    '''Create voltage values appending the existing array'''
    value = array[-1]
    startvalue = value
    if value < endvalue:
        while value < endvalue:
            value = value + ((endvalue-startvalue)/(samplerate_write*duration))
            array = np.append(array, value)
        return array
    elif value > endvalue:
        while value > endvalue:
            value = value - ((startvalue-endvalue)/(samplerate_write*duration))
            array = np.append(array, value)
        return array
    else:
        voltage_hold(array, duration)
        return array


def voltage_step(array, endvalue):
    array = np.append(array, endvalue)
    return array


def create_time_array(array):
    "Creates array with time values"

    time_buffer = range(0, len(array))
    time = [(x/samplerate_write) for x in time_buffer]
    return time


def save_to_file(filename, array):
    "Save array to csv file using pandas"

    time = create_time_array(array)
    time = np.array(time)

    # create array with time, array and headers
    output = pandas.DataFrame({'time': time,
                               'voltage': array})

    # save to csv-file
    output.to_csv(filename, index=False)

    print("Datei abgespeichert: ", filename)


def plot_array(array):
    "Show plot of created array"

    time = create_time_array(array)

    # Visualisierung
    plt.plot(time, array)
    plt.xlabel('Zeit in s')
    plt.ylabel('Spannung in V')
    plt.grid(True)
    plt.show()
