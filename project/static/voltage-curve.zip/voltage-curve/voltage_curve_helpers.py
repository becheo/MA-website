"Helper functions for voltage curve creation"

import numpy as np
import matplotlib.pyplot as plt
import pandas


samplerate_write = 250


class VoltageCurve():
    """Class for creating and saving the voltage curve

    This class can be used to create a voltage array and to save it to a
    csv (comma seperated values) file. If the file is created by this class
    the correct format condition for running tests on the website is satisfied.
    """

    def __init__(self):
        self.array = np.array([0], dtype=np.float64)

    def voltage_hold(self, duration):
        """Create voltage holding curve"""

        holdvalue = self.array[-1]
        value = np.array([np.repeat([holdvalue], (duration*samplerate_write))],
                         dtype=np.float64)  # 20 Sekunden bei 500 Hz
        self.array = np.append(self.array, value)

    def voltage_alter(self, duration, endvalue):
        """Create voltage values appending the existing array"""

        value = self.array[-1]
        startvalue = value
        if value < endvalue:
            while value < endvalue:
                value = value + ((endvalue-startvalue) /
                                 (samplerate_write*duration))
                self.array = np.append(self.array, value)
        elif value > endvalue:
            while value > endvalue:
                value = value - ((startvalue-endvalue) /
                                 (samplerate_write*duration))
                self.array = np.append(self.array, value)
        else:
            self.voltage_hold(duration)

    def voltage_step(self, endvalue):
        """Creates voltage step to desired endvalue"""

        self.array = np.append(self.array, endvalue)

    def create_time_array(self):
        """Creates array with time values"""

        time_buffer = range(0, len(self.array))
        self.time = [(x/samplerate_write) for x in time_buffer]

    def save_to_file(self, filename):
        """Save array to csv file using pandas"""

        self.create_time_array()
        self.time = np.array(self.time)

        # create array with time, array and headers
        output = pandas.DataFrame({'time': self.time,
                                   'voltage': self.array})

        # save to csv-file
        output.to_csv(filename, index=False)

        print("Datei abgespeichert: ", filename)

    def plot_array(self):
        """Show plot of created array"""

        self.create_time_array()

        # Visualisierung
        plt.plot(self.time, self.array)
        plt.xlabel('Zeit in s')
        plt.ylabel('Spannung in V')
        plt.grid(True)
        plt.show()
