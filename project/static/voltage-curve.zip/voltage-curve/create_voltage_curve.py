"""
Skript zum Erstellen eines Spannungsverlaufs für den Prüfstand

Fachgebiet MDT
Lehrveranstaltung: Modellbildung und Simulation mechatronischer Systeme
"""

import voltage_curve_helpers as hlp


filename = "Spannungsverlauf.csv"
voltage_curve = hlp.create_array()


# ++++++++++++++    Hier das gewuenschte Array erstellen    ++++++++++++++

# 5 s Anstieg bis 1.5 V
voltage_curve = hlp.voltage_alter(voltage_curve, 5, 1.5)

# 1.5 V für 10 Sekunden halten
voltage_curve = hlp.voltage_hold(voltage_curve, 10)

# 5 s Anstieg von 1.5 V auf 2 V
voltage_curve = hlp.voltage_alter(voltage_curve, 5, 2)

# 2 V 10 Sekunden halten
voltage_curve = hlp.voltage_hold(voltage_curve, 10)

# Abnahme bis 0 V in 10 Sekunden
voltage_curve = hlp.voltage_alter(voltage_curve, 10, 0)

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# Abspeichern als csv-Datei
hlp.save_to_file(filename, voltage_curve)

# Visualisierung
hlp.plot_array(voltage_curve)
