"""
Skript zum Erstellen eines Spannungsverlaufs für den Prüfstand.

Dieses Skript kann verwendet werden, um einen Spannungsverlauf zu erstellen,
sich diesen anzusehen und anschließend als csv-Datei zu speichern. Die 
csv-Datei kann dann auf die Prüfstands-Website hochgeladen werden um mit dieser
einen Test am Prüfstand durchzuführen. Der mögliche Spannungsbereich, in dem
der Motor operieren kann, ist dabei eingeschränkt. Dies muss bei der Erstellung
des Spannungsverlaufs beachtet werden.

Fachgebiet MDT
Lehrveranstaltung: Modellbildung und Simulation mechatronischer Systeme
"""

import voltage_curve_helpers as hlp


filename = "Spannungsverlauf.csv"
voltage_curve = hlp.VoltageCurve()

# ++++++++++++++    Hier das gewuenschte Array erstellen    ++++++++++++++

# 5 s Anstieg bis 1.5 V
voltage_curve.voltage_alter(10, 1.5)

# 1.5 V für 10 Sekunden halten
voltage_curve.voltage_hold(10)

# 5 s Anstieg von 1.5 V auf 2 V
voltage_curve.voltage_alter(5, 2)

# 2 V 10 Sekunden halten
voltage_curve.voltage_hold(10)

# Abnahme bis 0 V in 10 Sekunden
voltage_curve.voltage_alter(10, 0)

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# Abspeichern als csv-Datei
voltage_curve.save_to_file(filename)

# Visualisierung
voltage_curve.plot_array()
